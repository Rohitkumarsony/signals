from django.contrib import admin
from django.urls import path
from products.views import get_product

from django.conf import settings




urlpatterns = [
    path('<slug>/',get_product,name='get_product'),
]


